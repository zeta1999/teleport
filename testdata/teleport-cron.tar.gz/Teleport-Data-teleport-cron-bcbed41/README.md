# teleport-cron

The `cron` plugin for Teleport; it exports your Pad directory's Teleport schedule in crontab format.

## Prerequisites

This plugin depends on:

* `python3`

## Installation

From your Pad directory:

```
teleport plugin install cron
```

## Usage

1. Export the schedule with:

```
teleport plugin -- cron
```

2. Copy the printed output to your crontab file

## Example Output

```
$ teleport plugin -- cron
PADPATH=/Users/jason/Go/src/github.com/hundredwatt/teleport/testdata/pad
54 */1 * * * /usr/local/bin/teleport extract-load-api -from worldtimeapi_ip_times -to postgresdocker
24 */2 * * * /usr/local/bin/teleport extract-load-api -from example_widgets -to postgresdocker
48 13 */1 * * /usr/local/bin/teleport extract-load-db -from example -table objects -to postgresdocker
2 8 */1 * * /usr/local/bin/teleport transform -source postgresdocker -table times_by_day_of_week
```
